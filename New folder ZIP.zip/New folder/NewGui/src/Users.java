
public class Users {

    public Users(String user, String selectedFood, int[] ingredients) {
    }

    public Object getResult() {
        return null;
    }

    public Object getFood() {
        return null;
    }

    public Object getUser() {
        return null;
    }

}
