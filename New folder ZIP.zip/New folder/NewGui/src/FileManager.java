import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class FileManager {

    private File historyFile;

    public FileManager(String fileName) {
        this.historyFile = new File(fileName);
    }

    public void writeHistory(String input) {
        try {
            FileWriter writer = new FileWriter(historyFile, true); // true for append mode
            writer.write(input + "\n");
            writer.close();
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }
}
