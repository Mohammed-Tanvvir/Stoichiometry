abstract class Calculator {
    public abstract String calculate(int[] ingredients);
}